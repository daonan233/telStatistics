const path = require('path');

const config = {
    // 音频文件夹配置
    recordings: {
        // 默认的录音目录
        DEFAULT_RECORDINGS_DIR: '/usr/src/app/recordings',
        RECORDINGS_DIR: path.normalize(process.env.RECORDINGS_DIR ||  '/usr/src/app/recordings')
    },
    // 数据库配置
    database: {
        user: process.env.DB_USER || 'postgres',
        host: process.env.DB_HOST || '134.134.64.184',
        database: process.env.DB_NAME || 'cdr',
        password: process.env.DB_PASSWORD || 'Freeswitch20250303',
        port: parseInt(process.env.DB_PORT) || 5432,
        // 连接池配置
        pool: {
            max: 20,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    },
    // 服务器配置
    server: {
        port: parseInt(process.env.PORT) || 3000,
        host: process.env.HOST || '134.134.64.196'
    }
};

module.exports = config;