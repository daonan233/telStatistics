说明

这个项目包含一个基于 Streamlit 的小工具：`cdr_viewer.py`。

功能：
- 从项目根目录的 `cdr.sql` 解析 CDR 插入数据（用于练手的静态文件）。
- 根据 `destination_number` 模糊筛选、日期范围筛选。
- 显示：呼叫次数趋势、按小时分布、呼叫时长统计、匹配记录表。
- 支持导出 CSV。

使用方法（在已安装依赖的 Python 环境中）：
1. 安装依赖：
   pip install -r requirements.txt
2. 运行：
   streamlit run cdr_viewer.py

说明：代码以练习为主，解析逻辑对标准 INSERT 语句适用；若你的 `cdr.sql` 结构有差异，代码需相应调整。
