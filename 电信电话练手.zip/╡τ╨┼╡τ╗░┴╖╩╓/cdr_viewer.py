import re
import pandas as pd
from datetime import datetime
from pathlib import Path
import streamlit as st

# 读取并解析 cdr.sql 中的 INSERT 语句
SQL_PATH = Path(__file__).parent / "cdr.sql"

COLUMN_NAMES = [
    "id",
    "local_ip_v4",
    "caller_id_name",
    "caller_id_number",
    "destination_number",
    "context",
    "start_stamp",
    "answer_stamp",
    "end_stamp",
    "duration",
    "billsec",
    "hangup_cause",
    "uuid",
    "bleg_uuid",
    "accountcode",
    "read_codec",
    "write_codec",
    "sip_hangup_disposition",
    "ani",
    "final_dest",
    "caller_zh_name",
    "call_link_id",
    "leg_info",
    "gateway",
]


def split_sql_values(s: str):
    """把 SQL VALUES (...) 内部按逗号分割，支持单引号字符串和 NULL。"""
    tokens = []
    cur = []
    in_quote = False
    i = 0
    while i < len(s):
        ch = s[i]
        if ch == "'":
            # 处理 SQL 的单引号转义 ''
            if in_quote and i + 1 < len(s) and s[i + 1] == "'":
                cur.append("'")
                i += 2
                continue
            in_quote = not in_quote
            i += 1
            continue
        if ch == "," and not in_quote:
            token = "".join(cur).strip()
            tokens.append(token)
            cur = []
            i += 1
            continue
        cur.append(ch)
        i += 1
    # 添加最后一个
    if cur:
        tokens.append("".join(cur).strip())
    return tokens


def parse_value(tok: str):
    if tok == "NULL":
        return None
    tok = tok.strip()
    # 去掉外层单引号
    if len(tok) >= 2 and tok[0] == "'" and tok[-1] == "'":
        # 将 SQL 内部 '' 恢复为 '
        inner = tok[1:-1].replace("''", "'")
        return inner
    # 尝试解析为整数
    if re.fullmatch(r"[0-9]+", tok):
        return int(tok)
    return tok


@st.cache_data
def load_dataframe(sql_path: Path):
    rows = []
    with open(sql_path, "r", encoding="utf-8") as f:
        text = f.read()

    # 找到所有 INSERT INTO ... VALUES (...) ; 语句
    inserts = re.findall(
        r"INSERT INTO \"public\"\.\"cdr\" VALUES \((.*?)\);", text, flags=re.DOTALL
    )
    for ins in inserts:
        # ins 是不包含外围括号的字段内容
        tokens = split_sql_values(ins)
        parsed = [parse_value(t) for t in tokens]
        # 只保留我们已知的列数，多余忽略，少于补 None
        if len(parsed) < len(COLUMN_NAMES):
            parsed += [None] * (len(COLUMN_NAMES) - len(parsed))
        rows.append(parsed[: len(COLUMN_NAMES)])

    df = pd.DataFrame(rows, columns=COLUMN_NAMES)

    # 类型转换
    for col in ["start_stamp", "answer_stamp", "end_stamp"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    df["duration"] = (
        pd.to_numeric(df["duration"], errors="coerce").fillna(0).astype(int)
    )
    df["billsec"] = pd.to_numeric(df["billsec"], errors="coerce").fillna(0).astype(int)

    return df


def main():
    st.set_page_config(layout="wide", page_title="CDR 查看与统计")
    st.title("CDR 呼入号码频率 & 呼叫时长 可视化")

    if not SQL_PATH.exists():
        st.error(f"未找到 cdr.sql：{SQL_PATH}")
        return

    df = load_dataframe(SQL_PATH)

    # 侧边栏筛选
    st.sidebar.header("筛选条件")
    dest_input = st.sidebar.text_input("destination_number（支持模糊）", "")
    date_min = (
        df["start_stamp"].min().date() if not df["start_stamp"].isna().all() else None
    )
    date_max = (
        df["start_stamp"].max().date() if not df["start_stamp"].isna().all() else None
    )
    date_range = st.sidebar.date_input("呼叫日期范围", [date_min, date_max])

    # 过滤
    filtered = df.copy()
    if dest_input:
        filtered = filtered[
            filtered["destination_number"]
            .astype(str)
            .str.contains(dest_input, na=False)
        ]
    if (
        isinstance(date_range, (list, tuple))
        and len(date_range) == 2
        and date_range[0]
        and date_range[1]
    ):
        # 将用户选择的日期转为 Timestamp
        start_dt = pd.to_datetime(date_range[0])
        end_dt = (
            pd.to_datetime(date_range[1])
            + pd.Timedelta(days=1)
            - pd.Timedelta(seconds=1)
        )

        # 如果数据时间戳带有时区，则把用户的日期本地化为相同时区，避免比较时报错
        ts_tz = df["start_stamp"].dt.tz
        if ts_tz is not None:
            try:
                if start_dt.tzinfo is None:
                    start_dt = start_dt.tz_localize(ts_tz)
                    end_dt = end_dt.tz_localize(ts_tz)
            except Exception:
                # 如果本地化失败，尝试先以 UTC 本地化再转换
                try:
                    start_dt = start_dt.tz_localize("UTC").tz_convert(ts_tz)
                    end_dt = end_dt.tz_localize("UTC").tz_convert(ts_tz)
                except Exception:
                    pass

        filtered = filtered[
            (filtered["start_stamp"] >= start_dt) & (filtered["start_stamp"] <= end_dt)
        ]

    st.sidebar.markdown(f"匹配记录数：**{len(filtered)}**")

    # 基础统计
    st.subheader("基础统计")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("总通话次数", len(filtered))
    col2.metric("接通次数 (billsec>0)", int((filtered["billsec"] > 0).sum()))
    col3.metric("总通话时长 (秒, billsec)", int(filtered["billsec"].sum()))
    col4.metric(
        "平均接通时长 (秒)",
        round(filtered[filtered["billsec"] > 0]["billsec"].mean() or 0, 1),
    )

    # 日期频率趋势
    st.subheader("呼叫日期频率")
    if not filtered.empty:
        # 使用 resample 按天统计，能正确处理带时区的时间索引
        try:
            freq = filtered.set_index("start_stamp").resample("D").size()
        except Exception:
            # 退回到按 date 聚合的方式（不带时区信息）
            freq = filtered.groupby(filtered["start_stamp"].dt.date).size()
        st.line_chart(freq)
    else:
        st.info("无匹配数据")

    # 小时分布
    st.subheader("呼叫小时分布")
    if not filtered.empty:
        hour_counts = filtered["start_stamp"].dt.hour.value_counts().sort_index()
        st.bar_chart(hour_counts)

    # 显示匹配表格
    st.subheader("匹配记录（表格）")
    show_cols = [
        "id",
        "caller_id_number",
        "caller_zh_name",
        "destination_number",
        "start_stamp",
        "answer_stamp",
        "end_stamp",
        "duration",
        "billsec",
        "hangup_cause",
    ]
    st.dataframe(
        filtered[show_cols]
        .sort_values(by="start_stamp", ascending=False)
        .reset_index(drop=True)
    )

    # 导出 CSV
    csv = filtered.to_csv(index=False, encoding="utf-8")
    st.download_button(
        "导出为 CSV", data=csv, file_name="cdr_filtered.csv", mime="text/csv"
    )


if __name__ == "__main__":
    main()
